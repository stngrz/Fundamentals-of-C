//============================================================================
// Name        : 34_Pointer.cpp
// Author      : Jacob Kolb
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
/*
 void manipulate(double value){
 cout << "2. Value of double in manipulate: " << value << endl;
 value = 10;
 cout << "3. Value of double in manipulate: " << value << endl;
 }
 */

void manipulate(double *pValue) {//*value at address &address of value
	cout << "2. Value of double in manipulate: " << *pValue << endl;
	*pValue = 10; //changes what is in memory address to 10
	cout << "3. Value of double in manipulate: " << *pValue << endl;
}

int main() {

	int nValue = 8;
	nValue = 9;

	// * asterisk denotes a pointer -- & and sign is a pointer to the memory location
	int *pnValue = &nValue;

	//we can create a variable to store the memory location

	cout << "Int value: " << nValue << endl;
	cout << "Pointer to int address: " << pnValue << endl;
	cout << "Int Value via pointer: " << *pnValue << endl; //place * with var yields var value

	cout << "=======================" << endl;

	double dValue = 123.4;

	cout << "1. dValue: " << dValue << endl;
	//manipulate(dValue);//only makes change to dValue within certain scopes
	manipulate(&dValue); //must provide location address of varivable with &
	cout << "2. dValue: " << dValue << endl;

	return 0;
}
