//outputting text
#include <iostream>//input output stream

using namespace std;
//standard

int main() { // a subroutine a function
	//cout to output \ endl flushes the buffer clearing out any sititng text
	cout << "Starting Program..." << flush;

	cout << "This is some text." << endl;

	cout << "Banana. " << "Apple. " << "Orange." << endl;

	cout << "This is some more text." << endl;
	return 0;	//a statement
}
