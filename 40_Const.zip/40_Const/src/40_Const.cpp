//============================================================================
// Name        : 40_Const.cpp
// Author      : Jacob Kolb
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Animal{
private:
	string name;

public:
	void setName(string name) {this->name = name;};
	void speak()const{cout << "My name is: " << name << endl;}//using const with the method here to prevent any chance of change something unintentionally
};

int main() {

	const int value = 7;
	//value = 10;// this does not woke, it will not change the value to 10
	cout << value << endl;

	const double PI = 3.141592;// constant variables often have their names in ALL CAPS
	cout << PI << endl;


	Animal animal;
	animal.setName("Doggie");
	animal.speak();

	int value2 = 8;
	int *pValue2 = &value2;//const int *const pValue2 = &value2; ERROR for both statements below

	cout << *pValue2 << endl;

	int number = 11;
	pValue2 = &number;// int *const pValue2 = &value2; ERROR
	*pValue2 = 12;// const int *pValue2 = &value2; ERROR

	cout << *pValue2 << endl;

	return 0;
}
