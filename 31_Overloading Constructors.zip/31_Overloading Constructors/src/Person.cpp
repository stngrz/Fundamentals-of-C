/*
 * Person.cpp
 *
 *  Created on: Jun 22, 2017
 *      Author: JKolb
 */
#include <sstream>
#include "Person.h"

Person::Person() {
	// TODO Auto-generated constructor stub
	name = "undefined";
	age = 0;
}

Person::Person(string newName, int newAge){
	name = newName;
	age = newAge;
}

//implementing methods
string Person::toString(){
	stringstream ss;

	ss << "Name: ";
	ss << name;
	ss << "; age: ";
	ss << age;

	return ss.str();
}
