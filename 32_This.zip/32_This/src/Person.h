/*
 * Person.h
 *
 *  Created on: Jun 22, 2017
 *      Author: JKolb
 */

#ifndef PERSON_H_
#define PERSON_H_

#include <iostream>

using namespace std;

//model a person in this class, say an employee data base
class Person {
private:
	string name;
	int age;
public:
	Person();//std method, blow is method with overload, meaning if Person is used and given a variable it will be over loaded
	Person(string newName){name = newName; age=0;};//inline implementation
	Person(string newName, int newAge);

	//a method to see what is in the class
	string toString();
};

#endif /* PERSON_H_ */
