/*
 * Item.h
 *
 *  Created on: Jun 24, 2017
 *      Author: JKolb
 */

#ifndef ITEM_H_
#define ITEM_H_

#include <sstream>

using namespace std;


class Item {
private:
	string name;
	float value;
public:
	Item();
	Item(string name, float value):name(name),value(value){};

	string toString();

};

#endif /* ITEM_H_ */
