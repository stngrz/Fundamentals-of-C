/*
 * Item.cpp
 *
 *  Created on: Jun 24, 2017
 *      Author: JKolb
 */

#include "Item.h"
#include <sstream>
#include <iomanip>


string Item::toString(){
	stringstream ss;

	ss << "Name: ";
	ss << name;
	ss << "; value: $";
	ss << setprecision(2) << fixed << value;

	return ss.str();
}
