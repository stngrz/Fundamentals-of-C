//============================================================================
// Name        : 1_Practice.cpp
// Author      : Jacob Kolb
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Item.h"

using namespace std;

int main() {

	cout << "Enter item name: " << flush;
	string name;
	cin >> name;
	cout <<"Enter item $ value: " << flush;
	float value;
	cin >> value;

	Item item1(name,value);

	cout << item1.toString() << endl; // prints !!!Hello World!!!
	return 0;
}
