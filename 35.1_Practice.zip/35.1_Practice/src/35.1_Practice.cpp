//============================================================================
// Name        : 1_Practice.cpp
// Author      : Jacob Kolb
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

double cSec;
int mSec;
double cMin;
double cHrs;
double cDay;
double secIn;

void convertToHours(int seconds) {
	cHrs = seconds / 3600;
	mSec = seconds % 3600;
}

void convertToMinutes(int modSec) {
	cMin = modSec / 60;
	mSec = modSec % 60;
}

int main() {

	cout << "Enter amount of seconds > " << flush;
	cin >> secIn;
	cout << secIn << endl;
	convertToHours(secIn);
	convertToMinutes(mSec);
	cout << "Hours: " << cHrs << " ** Minutes: " << cMin << " ** Seconds: "	<< mSec << endl;
	cout << "Total Seconds: " << (cHrs * 3600) + (cMin * 60) + mSec << endl;

	return 0;
}
