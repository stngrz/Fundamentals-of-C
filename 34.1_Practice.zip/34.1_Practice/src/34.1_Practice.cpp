//============================================================================
// Name        : 1_Practice.cpp
// Author      : Jacob Kolb
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

void update(string *nName) {

	cout << "UPDATE: Changing from: " << *nName;

	*nName = "R";

	cout << " to: " << *nName << endl;
}

int main() {

	string name = "J";

	string *pName = &name; //the location (&) of name = name of pointed

	cout << "At: " << &name << " name via pointer: " << *pName << endl;

	update(&name);

	cout << "At: " << &name << " name via pointer: " << *pName << endl;

	return 0;
}
