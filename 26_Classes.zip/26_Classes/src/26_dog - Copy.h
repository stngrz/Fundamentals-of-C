/*
 * dog.h
 *
 *  Created on: Jun 19, 2017
 *      Author: JKolb
 */

#ifndef DOG_H_
#define DOG_H_

class Dog {
public:
	void speak();
	void jump();
};




#endif /* DOG_H_ */
