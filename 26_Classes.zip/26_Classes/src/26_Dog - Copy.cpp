/*
 * Dog.cpp
 *
 *  Created on: Jun 19, 2017
 *      Author: JKolb
 */

#include <iostream>
#include "dog.h"

using namespace std;

void Dog::speak(){
	cout << "Woof" << endl;
}

void Dog::jump(){
	cout << "Dog jumps on person" <<endl;
}


