/*
 * Cat.h
 *
 *  Created on: Jun 19, 2017
 *      Author: JKolb
 */

#ifndef CAT_H_
#define CAT_H_

//Cat.h is a java format

class Cat {
public://makes these accessable outside of this class
	void speak();
	void jump();
};

#endif /* CAT_H_ */
