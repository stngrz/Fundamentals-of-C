/*
 * Cat.cpp
 *
 *  Created on: Jun 19, 2017
 *      Author: JKolb
 */

#include <iostream>
#include "Cat.h"

using namespace std;//namespace a way of dividing up code

void Cat::speak(){
	cout << "Meow" << endl;
}

void Cat::jump(){
	cout << "Cat jumps to lap" << endl;
}
