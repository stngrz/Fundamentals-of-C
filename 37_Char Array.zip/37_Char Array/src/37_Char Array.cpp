//============================================================================
// Name        : 37_Char.cpp
// Author      : Jacob Kolb
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

//create a char string and output it
//output chars with for loop
//out put chars in while loop



int main() {

	//string text = "hello";
	//cout << text;

	//chars are a byte useful to sort characters in char array
	char text[] = "hello";

	for (int i = 0; i < sizeof(text); i++) {
		cout << i << ": " << text[i] << " char as int: " << (int) text[i]
				<< endl;
	}

	//sometimes while loops are usefull like for loops
	int k = 0;
	while (true) {

		if (text[k] == 0)
			break;//ifs are allow to forgo {} when they are a single like like here

		cout << text[k] << flush;

		k++;
	}

	return 0;
}
