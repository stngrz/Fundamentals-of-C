/*
 * utils.h
 *
 *  Created on: Jun 19, 2017
 *      Author: JKolb
 */

#ifndef UTILS_H_
#define UTILS_H_

void doSomething();

#endif /* UTILS_H_ */
