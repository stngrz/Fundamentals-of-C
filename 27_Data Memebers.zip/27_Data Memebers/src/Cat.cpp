/*
 * Cat.cpp
 *
 *  Created on: Jun 19, 2017
 *      Author: JKolb
 */
#include <iostream>
#include "Cat.h"

using namespace std;

Cat::Cat(){//constructor
	cout << "Cat Created" << endl;
	happy = true;
}
