/*
 * Cat.h
 *
 *  Created on: Jun 19, 2017
 *      Author: JKolb
 */

#ifndef CAT_H_
#define CAT_H_

class Cat { //giving cat a method
private:
	bool happy;//instance variable
public:

	void speak(); //prototype of method
	Cat();//constructor - no return types not even void

};

#endif /* CAT_H_ */
