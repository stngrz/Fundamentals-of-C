/*
 * Cat.h
 *
 *  Created on: Jun 19, 2017
 *      Author: JKolb
 */

#ifndef CAT_H_
#define CAT_H_

class Cat { //giving cat a method
private:
	bool happy;//instance bariable
public:
	void makeHappy();
	void makeSad();
	void speak(); //prototype of method

};

#endif /* CAT_H_ */
