//============================================================================
// Name        : 41_Copy.cpp
// Author      : Jacob Kolb
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Animal {
private:
	string name; //instance member

public:
	Animal(){cout << "Animal created." << endl;};//constructor for Animal
	//Animal(const Animal& other){name = other.name; cout << "Animal created by copying." << endl;};//accessing private fields
	Animal(const Animal& other):name(other.name){cout << "Animal created by copying." << endl;};//accessing private fields
	void setName(string name) {	this->name = name;}	; //method
	void speak() const {cout << "My name is: " << name << endl;} //method
};

int main() {

	Animal animal1;

	animal1.setName("Fred");

	Animal animal2 = animal1;//envokes COPY CONSTRUCTOR creating two animal ojbects
	animal2.speak();
	animal2.setName("Mike");

	animal1.speak();
	animal2.speak();

	Animal animal3(animal1);
	animal3.speak();

	return 0;
}
