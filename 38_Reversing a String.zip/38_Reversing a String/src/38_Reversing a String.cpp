//============================================================================
// Name        : 38_Reversing.cpp
// Author      : Jacob Kolb
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {

	char text[] = "hello";

	int nChars = sizeof(text) - 1; //for numbers of charactes -1//each char is one byte, so sizeof whole array will yield the number of characters in the array in the whole string

	char *pStart = text;
	char *pEnd = text + nChars - 1;

	cout << "Pointing to the last char: " << *pEnd << endl;
	cout << "Pointing to the first char: " << *pStart << endl;

	while (pStart < pEnd) {

		char save = *pStart; //save the thing you want to swap
		*pStart = *pEnd;
		*pEnd = save;

		pStart++;
		pEnd--;
	}

	cout << text << endl;

	return 0;
}
