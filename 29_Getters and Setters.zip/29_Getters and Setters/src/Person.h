/*
 * Person.h
 *
 *  Created on: Jun 20, 2017
 *      Author: JKolb
 */

#ifndef PERSON_H_
#define PERSON_H_

#include <iostream>

using namespace std;

//declaring attributes
class Person {//classes are data structures like arrays, not functions, henc the end with a semicolon
private://access specifier
	string name;

public://access specifier
	//prototype declarations
	Person();
	string toString();
	void setName(string newName);
	string getName();
};

#endif /* PERSON_H_ */
