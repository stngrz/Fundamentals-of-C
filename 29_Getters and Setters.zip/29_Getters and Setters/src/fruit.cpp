/*
 * fruit.cpp
 *
 *  Created on: Jun 20, 2017
 *      Author: JKolb
 */

#include "fruit.h"

fruit::fruit() {

}

void fruit::setPrice(int perPound){
	newPrice = perPound;
}

void fruit::setName(string newName){
	nameF = newName;
}

void fruit::setWeight(int newPound){
	pound = newPound;
}

int fruit::cost(){
	return perPound * pound;
}

string fruit::receipt(){
	return "Fruit " + nameF;
}

