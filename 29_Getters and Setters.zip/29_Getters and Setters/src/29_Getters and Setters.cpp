//============================================================================
// Name        : 29_Getters.cpp
// Author      : Jacob Kolb
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <iomanip>
#include "Person.h"
#include "fruit.h"

using namespace std;

//main function
int main() {

	cout << "Enter name: " << flush;
	string nameIn;
	cin >> nameIn;
	Person person;
	person.setName(nameIn);//accesses
	cout << person.toString() << endl;
	cout << "Name of person with get method: " << person.getName() << endl;

	cout << "FRUITS" << endl;
	cout << "======" << endl;
	fruit fruit;
	cout << "Enter fruit name: " << flush;
	string fruitName;
	cin >> fruitName;
	fruit.setName(fruitName);
	cout << "Enter $/lb: " << flush;
	float perLB;
	cin >> perLB;
	fruit.setPrice(perLB);
	cout << "Enter lbs: " << flush;
	float lb;
	cin >> lb;
	fruit.setWeight(lb);

	cout << fruit.receipt()<< " $" << setprecision(2) << fixed << perLB*lb << endl;

	return 0;
}
