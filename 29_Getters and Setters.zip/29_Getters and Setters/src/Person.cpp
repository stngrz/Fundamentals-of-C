/*
 * Person.cpp
 *
 *  Created on: Jun 20, 2017
 *      Author: JKolb
 */

#include "Person.h"

//attribute implementation/actions being declared out side of the class
//using the scope resolution operator :: to relate it back to the fruit

Person::Person() {
	name = "George";

}

string Person::toString(){
	return "Person's name is: " + name;
}

void Person::setName(string newName) {
	name = newName;//set method.
}

string Person::getName(){
	return name;
}
