/*
 * fruit.h
 *
 *  Created on: Jun 20, 2017
 *      Author: JKolb
 */

#ifndef FRUIT_H_
#define FRUIT_H_

#include <iostream>

using namespace std;

class fruit {
private:
	int newPrice;
public:
	fruit();
	string nameF;
	int pound;
	int perPound;
	int cost();
	void setPrice(int perPound);
	void setName(string newName);
	void setWeight(int pound);
	string receipt();
};

#endif /* FRUIT_H_ */
