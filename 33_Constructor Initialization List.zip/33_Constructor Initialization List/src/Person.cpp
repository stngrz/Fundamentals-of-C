/*
 * Person.cpp
 *
 *  Created on: Jun 22, 2017
 *      Author: JKolb
 */
#include <sstream>
#include "Person.h"

/*Person::Person() {//: name("unnamed"),age(0){//initialization list

}*/

/*Person::Person(string name, int age){
	//this reduces redundant variable names
	//is a pointer to memory location
	this->name = name;//same as saying name = newName; with string newName being the input var
	this->age = age;//common and useful

	cout << "Memory location of object: " << this << endl;
}*/

/*Person::Person(string name, int age):name(name),age(age){
	//list to initialize variables in cpp
}*/

//implementing methods
string Person::toString(){
	stringstream ss;

	ss << "Name: ";
	ss << name;
	ss << "; age: ";
	ss << age;

	return ss.str();
}
