/*
 * Person.h
 *
 *  Created on: Jun 22, 2017
 *      Author: JKolb
 */

#ifndef PERSON_H_
#define PERSON_H_

#include <iostream>

using namespace std;

//model a person in this class, say an employee data base
class Person {
private:
	string name;
	int age;
public:
	Person(): name("unnamed"),age(0){};//implementation in cpp is not long needed//std method, blow is method with overload, meaning if Person is used and given a variable it will be over loaded
	Person(string name,int age):name(name),age(age){};//in-line implementation

	//a method to see what is in the class
	string toString();
};

#endif /* PERSON_H_ */
