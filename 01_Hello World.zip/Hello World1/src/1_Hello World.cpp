//Hello World
//easy peasy

#include <iostream>

using namespace std;//std = standard

int main() {//int = type declaration; main = function or subroutine
	//cout c-out object \ << insertion operator \ endl creates new line
	cout << "Hello World :)"<< endl;

	return 0; //0 usually means everything is fine
}
