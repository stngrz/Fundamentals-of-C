//============================================================================
// Name        : 36_Pointers.cpp
// Author      : Jacob Kolb
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
//Loop through an array using a pointer, with array element reference syntad
//Loop through an array by incrementing a pointer
//Loot through an array, stopping by comparing two pointers
int main() {

	string text[] = { "one", "two", "three" };

	string *pText = text; //point directly to array

	//cout << sizeof(text)/sizeof(string) << endl;

	for (int i = 0; i < sizeof(text) / sizeof(string); i++) {
		cout << pText[i] << " " << flush;
	}

	cout << endl; // for better visualization
	for (int i = 0; i < sizeof(text) / sizeof(string); i++, pText++) {
		cout << *pText << " " << flush; //gives value
	}

	cout << endl;

	string *pElement = &text[0]; //address of start
	string *pEnd = &text[2]; //address of element

	while (true) {
		cout << *pElement << " " << flush;

		if (pElement == pEnd) {
			break;
		}
		pElement++;
	}

	return 0;
}
