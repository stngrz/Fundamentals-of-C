/*
 * Cat.cpp
 *
 *  Created on: Jun 19, 2017
 *      Author: JKolb
 */
#include <iostream>
#include "Cat.h"

using namespace std;

Cat::Cat(){
	cout << "Cat created" << endl;
	happy = true;
}

Cat::~Cat(){
	cout << "Cat destroyed" << endl;
}

void Cat::speak() {
	if(happy){
	cout << "Meow" << endl;
	}else{
		cout<< "SSssss" << endl;
	}
}

