//============================================================================
// Name        : Arithmetic.cpp
// Author      : Jacob Kolb
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

/*
 * +
 * -
 * *
 * /
 * +=
 * -=
 * *=
 * %
 * %=
 * precedence
 */

//Take large amount seconds and convert into days,
//hours, minutes, and seconds then convert back
//into seconds and verify that we have the same

//Write a  for loop to iterate 10,000 times;
//output a dot for every 100 using mod (%)
//(dots on the same line)

int main() {

	//double cast for division
	double value1 = (double) 7 / 2;
	cout << value1 << endl;

	int value2 = (int) 7.3; //does not round
	cout << value2 << endl;

	int value3 = 8;
	value3 += 1; // value3 = value3 + 1 or value3++;
	cout << value3 << endl;

	int value4 = 10;
	value4 /= 5; // value4 = value4/5;
	cout << value4 << endl;

	int value5 = 12 % 5; //mod, modulus takes product and stores remainder
	cout << value5 << endl;

	double equation = 5.3 / 4 + 2 * 6;
	cout << equation << endl;

	double equation2 = ((5/4)%2)+(2.3*6);//hard to read 5/4%2+2.3*6
	cout << equation2 << endl;

	return 0;
}
